using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FatecLibrary.Pages.Account;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}